	</div>
	<footer>Webstore 2017</footer>
	<script src="assets/js/script.js"></script>
	<?php if(isset($user)) { echo "<script>user_id = ".$user->getId()."</script>"; } ?>
</body>
</html>